CREATE TABLE [master].[dbo].[customers]
(
    [customer_id] INT IDENTITY (1,1) NOT NULL,
    [name] VARCHAR(32)
)
